
class QuoteScriptError(Exception):
    """Custom error for QuoteScript compile/execute issues."""
    pass
